package com.yuchen.ycf;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.*;

public class YcfCommand {

    private static final Map<String, CommandEntry> COMMAND_MAP = new LinkedHashMap<>();
    private static int autoId = 0;

    private static class Variable {
        final String name;
        final String type;

        Variable(String name, String type) {
            this.name = name;
            this.type = type;
        }
    }

    private static class CommandEntry {
        final String id;
        final String template;
        final List<Variable> variables;

        CommandEntry(String id, String template, List<Variable> variables) {
            this.id = id;
            this.template = template;
            this.variables = variables;
        }
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
            CommandManager.literal("ycf")
                .then(CommandManager.literal("add")
                    .then(CommandManager.argument("template", StringArgumentType.greedyString())
                        .executes(YcfCommand::handleAdd)))
                .then(CommandManager.literal("use")
                    .then(CommandManager.argument("id", StringArgumentType.word())
                        .then(CommandManager.argument("params", StringArgumentType.greedyString())
                            .executes(YcfCommand::handleUse))))
                .then(CommandManager.literal("del")
                    .then(CommandManager.argument("id", StringArgumentType.word())
                        .executes(YcfCommand::handleDel)))
                .then(CommandManager.literal("list")
                    .executes(YcfCommand::handleList))
        );
    }

    private static int handleAdd(CommandContext<ServerCommandSource> ctx) {
        String raw = StringArgumentType.getString(ctx, "template");
        ServerCommandSource src = ctx.getSource();

        String id = null;
        String cmdTemplate = raw;
        if (raw.contains(" ")) {
            String last = raw.substring(raw.lastIndexOf(" ") + 1);
            if (!last.contains("<") && !last.contains(">") && last.matches("[a-zA-Z0-9_]+")) {
                id = last;
                cmdTemplate = raw.substring(0, raw.lastIndexOf(" "));
            }
        }

        List<Variable> vars = new ArrayList<>();
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("<([a-zA-Z0-9_]+)-([a-zA-Z]+)>");
        java.util.regex.Matcher m = p.matcher(cmdTemplate);
        Set<String> names = new HashSet<>();
        while (m.find()) {
            String name = m.group(1);
            String type = m.group(2).toLowerCase();
            if (!isValidType(type)) {
                src.sendFeedback(() -> Text.literal("未知变量类型: " + type).formatted(Formatting.RED), false);
                return 0;
            }
            if (!names.add(name)) {
                src.sendFeedback(() -> Text.literal("变量名重复: " + name).formatted(Formatting.RED), false);
                return 0;
            }
            vars.add(new Variable(name, type));
        }

        if (id == null || id.isEmpty()) {
            id = String.valueOf(++autoId);
            while (COMMAND_MAP.containsKey(id)) {
                id = String.valueOf(++autoId);
            }
        } else if (COMMAND_MAP.containsKey(id)) {
            src.sendFeedback(() -> Text.literal("ID已存在: " + id).formatted(Formatting.RED), false);
            return 0;
        }

        COMMAND_MAP.put(id, new CommandEntry(id, cmdTemplate, vars));
        src.sendFeedback(() -> Text.literal("已添加命令，ID: " + id + " | 模板: " + cmdTemplate).formatted(Formatting.GREEN), false);
        return 1;
    }

    private static int handleUse(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, "id");
        String paramStr = StringArgumentType.getString(ctx, "params");
        ServerCommandSource src = ctx.getSource();

        CommandEntry entry = COMMAND_MAP.get(id);
        if (entry == null) {
            src.sendFeedback(() -> Text.literal("未找到命令: " + id).formatted(Formatting.RED), false);
            return 0;
        }

        String[] userParams = paramStr.split(" ");
        int expected = 0;
        for (Variable v : entry.variables) {
            if (v.type.equals("pos")) expected += 3;
            else expected += 1;
        }
        if (userParams.length != expected) {
            src.sendFeedback(() -> Text.literal("参数数量错误，需要" + expected + "个，提供了" + userParams.length + "个").formatted(Formatting.RED), false);
            return 0;
        }

        Map<String, String> reps = new LinkedHashMap<>();
        int idx = 0;
        try {
            for (Variable v : entry.variables) {
                switch (v.type) {
                    case "user":
                    case "text":
                    case "item":
                    case "world":
                        reps.put(v.name, userParams[idx++]);
                        break;
                    case "int":
                        Integer.parseInt(userParams[idx]);
                        reps.put(v.name, userParams[idx++]);
                        break;
                    case "float":
                        Float.parseFloat(userParams[idx]);
                        reps.put(v.name, userParams[idx++]);
                        break;
                    case "bool":
                        if (!userParams[idx].equalsIgnoreCase("true") && !userParams[idx].equalsIgnoreCase("false")) {
                            throw new IllegalArgumentException("布尔值必须为true/false");
                        }
                        reps.put(v.name, userParams[idx++]);
                        break;
                    case "pos":
                        String x = userParams[idx++];
                        String y = userParams[idx++];
                        String z = userParams[idx++];
                        Double.parseDouble(x);
                        Double.parseDouble(y);
                        Double.parseDouble(z);
                        reps.put(v.name, x + " " + y + " " + z);
                        break;
                    default:
                        reps.put(v.name, userParams[idx++]);
                }
            }
        } catch (NumberFormatException e) {
            src.sendFeedback(() -> Text.literal("数字格式错误").formatted(Formatting.RED), false);
            return 0;
        } catch (IllegalArgumentException e) {
            src.sendFeedback(() -> Text.literal(e.getMessage()).formatted(Formatting.RED), false);
            return 0;
        }

        String command = entry.template;
        for (Map.Entry<String, String> r : reps.entrySet()) {
            command = command.replaceAll("<" + java.util.regex.Pattern.quote(r.getKey()) + "-[a-zA-Z]+>", r.getValue());
        }

        src.getServer().getCommandManager().executeWithPrefix(src, command);
        src.sendFeedback(() -> Text.literal("已执行命令").formatted(Formatting.GREEN), false);
        return 1;
    }

    private static int handleDel(CommandContext<ServerCommandSource> ctx) {
        String id = StringArgumentType.getString(ctx, "id");
        ServerCommandSource src = ctx.getSource();
        if (COMMAND_MAP.remove(id) != null) {
            src.sendFeedback(() -> Text.literal("已删除命令: " + id).formatted(Formatting.GREEN), false);
        } else {
            src.sendFeedback(() -> Text.literal("未找到命令: " + id).formatted(Formatting.RED), false);
        }
        return 1;
    }

    private static int handleList(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource src = ctx.getSource();
        if (COMMAND_MAP.isEmpty()) {
            src.sendFeedback(() -> Text.literal("当前无保存的命令").formatted(Formatting.YELLOW), false);
            return 1;
        }
        src.sendFeedback(() -> Text.literal("--- 命令列表 ---").formatted(Formatting.GOLD), false);
        for (CommandEntry e : COMMAND_MAP.values()) {
            src.sendFeedback(() -> Text.literal("[" + e.id + "] " + e.template).formatted(Formatting.WHITE), false);
        }
        return 1;
    }

    private static boolean isValidType(String type) {
        return Arrays.asList("user", "text", "int", "float", "pos", "item", "world", "bool").contains(type);
    }
}
